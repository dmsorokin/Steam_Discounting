#' @useDynLib conquer
#' @importFrom Rcpp evalCpp
#' @importFrom matrixStats rowSds rowQuantiles colSds
#' @importFrom stats qnorm
#' @importFrom Matrix rankMatrix
NULL
