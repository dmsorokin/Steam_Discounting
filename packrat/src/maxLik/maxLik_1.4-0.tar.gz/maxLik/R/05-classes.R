## first to be loaded:
setOldClass(c("maxLik", "maxim"))
