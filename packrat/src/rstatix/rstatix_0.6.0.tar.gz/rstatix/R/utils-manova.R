#' Manova exported from car package
#'
#' See \code{car::\link[car:Anova]{Manova}} for details.
#'
#' @name Manova
#' @rdname Manova
#' @keywords internal
#' @export
#' @importFrom car Manova
NULL
