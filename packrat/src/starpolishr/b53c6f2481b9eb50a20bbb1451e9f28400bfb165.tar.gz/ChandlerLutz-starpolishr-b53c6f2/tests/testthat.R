library(testthat)
library(starpolishr)

test_check("starpolishr")
